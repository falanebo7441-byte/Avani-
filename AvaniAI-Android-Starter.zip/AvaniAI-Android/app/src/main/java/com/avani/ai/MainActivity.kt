package com.avani.ai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var speech: TextToSpeech
    private var recognizer: SpeechRecognizer? = null
    private lateinit var chat: LinearLayout
    private lateinit var status: TextView
    private lateinit var listenButton: Button
    private val requestAudio = 41

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        speech = TextToSpeech(this, this)
        buildScreen()
        addMessage("Avani", "Hello Rahitya! ❤️ I miss you! बताओ, आज मैं तुम्हारी क्या मदद कर सकती हूँ?")
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), requestAudio)
        }
    }

    private fun buildScreen() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 42, 28, 28)
            setBackgroundColor(0xFF090B1A.toInt())
        }
        val title = TextView(this).apply {
            text = "AVANI AI"
            textSize = 30f
            gravity = Gravity.CENTER
            setTextColor(0xFFEDE9FE.toInt())
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        val subtitle = TextView(this).apply {
            text = "Your personal Hindi AI assistant"
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(0xFFB8B5D1.toInt())
            setPadding(0, 6, 0, 24)
        }
        status = TextView(this).apply {
            text = "● Ready"
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(0xFF86EFAC.toInt())
            setPadding(0, 4, 0, 16)
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(0xFF12152A.toInt())
        }
        chat = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 16)
        }
        scroll.addView(chat)
        listenButton = Button(this).apply {
            text = "🎙  Avani se baat karo"
            textSize = 17f
            setOnClickListener { startListening() }
        }
        val hint = TextView(this).apply {
            text = "माइक दबाकर हिंदी या English में बोलें"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(0xFFB8B5D1.toInt())
            setPadding(0, 8, 0, 0)
        }
        page.addView(title)
        page.addView(subtitle)
        page.addView(status)
        page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        page.addView(listenButton)
        page.addView(hint)
        setContentView(page)
    }

    private fun addMessage(who: String, message: String) {
        val bubble = TextView(this).apply {
            text = "$who\n$message"
            textSize = 16f
            setTextColor(0xFFF5F3FF.toInt())
            setBackgroundColor(if (who == "You") 0xFF29234A.toInt() else 0xFF202944.toInt())
            setPadding(18, 14, 18, 14)
        }
        val params = LinearLayout.LayoutParams(-1, -2).apply {
            setMargins(0, 0, 0, 14)
        }
        chat.addView(bubble, params)
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "इस फोन में speech recognition उपलब्ध नहीं है।", Toast.LENGTH_LONG).show()
            return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), requestAudio)
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : android.speech.RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { status.text = "● सुन रही हूँ…"; listenButton.isEnabled = false }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { status.text = "● सोच रही हूँ…" }
            override fun onError(error: Int) {
                status.text = "● Ready"; listenButton.isEnabled = true
                Toast.makeText(this@MainActivity, "आवाज़ समझ नहीं आई। फिर कोशिश करें।", Toast.LENGTH_SHORT).show()
            }
            override fun onResults(results: Bundle?) {
                listenButton.isEnabled = true
                status.text = "● Ready"
                val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!spoken.isNullOrBlank()) {
                    addMessage("You", spoken)
                    respond(spoken)
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Avani से बात करें")
        }
        recognizer?.startListening(intent)
    }

    // Starter replies work offline. Connect a secure AI backend here for open-ended AI answers.
    private fun respond(input: String) {
        val normalized = input.lowercase(Locale.ROOT)
        val answer = when {
            normalized.contains("hello") || normalized.contains("हेलो") ||
                normalized.contains("नमस्ते") || normalized.contains("हाय") ->
                "Hello Rahitya! ❤️ I miss you! बताओ, क्या बात है?"
            normalized.contains("तुम कौन") || normalized.contains("who are you") ->
                "मैं Avani हूँ, तुम्हारी हिंदी AI assistant."
            normalized.contains("समय") || normalized.contains("time") ->
                "मैं अभी इंटरनेट से live जानकारी नहीं ले रही हूँ।"
            normalized.contains("धन्यवाद") || normalized.contains("thank") ->
                "आपका स्वागत है, Rahitya! ❤️"
            else ->
                "मैंने सुना: $input. अभी मेरा शुरुआती version है। सामान्य सवालों के जवाब देने के लिए इसमें सुरक्षित AI server जोड़ना बाकी है।"
        }
        addMessage("Avani", answer)
        speak(answer)
    }

    private fun speak(text: String) {
        if (::speech.isInitialized) {
            speech.language = Locale("hi", "IN")
            speech.setSpeechRate(0.92f)
            speech.speak(text, TextToSpeech.QUEUE_FLUSH, null, "avani_reply")
        }
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            val result = speech.setLanguage(Locale("hi", "IN"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                speech.language = Locale.US
            }
        }
    }

    override fun onDestroy() {
        recognizer?.destroy()
        if (::speech.isInitialized) {
            speech.stop()
            speech.shutdown()
        }
        super.onDestroy()
    }
}
