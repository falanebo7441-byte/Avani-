# AVANI AI — Android starter project

यह एक शुरुआती Android Studio प्रोजेक्ट है। इसमें:
- हिंदी speech recognition (फोन की उपलब्ध speech service के ज़रिये)
- Android Text-to-Speech से जवाब बोलना
- AVANI AI की शुरुआती चैट स्क्रीन
- शुरुआती offline greeting और demo replies

## APK कैसे बनाएँ
1. कंप्यूटर पर Android Studio इंस्टॉल करें।
2. Android Studio में `AvaniAI` फ़ोल्डर खोलें।
3. Gradle sync पूरा होने दें।
4. फोन को USB से जोड़ें या emulator चुनें।
5. Build → Build Bundle(s) / APK(s) → Build APK(s) चुनें।
6. APK आम तौर पर `app/build/outputs/apk/debug/app-debug.apk` में मिलेगा।

## ज़रूरी बातें
- यह अभी starter prototype है, पूरा online AI assistant नहीं।
- खुले सवालों के AI जवाब, internet search और याद रखने की सुविधा जोड़ने के लिए सुरक्षित backend/API और अलग से implementation चाहिए।
- API secret को APK के अंदर कभी न रखें। उसे अपने secure server पर रखें।
- माइक अनुमति देने पर ही voice input चलेगा।
- आवाज़ फोन में उपलब्ध Hindi TTS voice पर निर्भर करेगी। बेहतर महिला आवाज़ के लिए Android Settings → Text-to-speech output में Hindi voice चुनें, अगर उपलब्ध हो।
- "Rahitya" greeting text को MainActivity.kt में बदला जा सकता है।
